__title__ = 'pipy'
__version__ = '1.0.1'
__description__ = 'A native Python wrapper around the command line program: `pip`'
__url__ = 'https://github.com/mmongeon-sym/pipy'
__author__ = 'mmongeon-sym'
__author_email__ = '36868044+mmongeon-sym@users.noreply.github.com'
__license__ = 'Unlicense, no rights reserved, https://unlicense.org/'


